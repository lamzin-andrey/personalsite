<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DtoSrvTask
 *
 * @ORM\Table(name="dto_srv_task", indexes={@ORM\Index(name="user_id", columns={"user_id"})})
 * @ORM\Entity
 */
class DtoSrvTask
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true, options={"comment"="Узнаваемое имя задачи."})
     */
    private $name;

    /**
     * @var int|null
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true, options={"comment"="Ссылка на таблицу пользователей"})
     */
    private $userId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="json", type="text", length=65535, nullable=true, options={"comment"="Исходный JSON"})
     */
    private $json;

    /**
     * @var int|null
     *
     * @ORM\Column(name="class_name_idx", type="integer", nullable=true, options={"comment"="Число в сгенерированом имени класса, например Class_1_Dto"})
     */
    private $classNameIdx;

    /**
     * @var string|null
     *
     * @ORM\Column(name="src_dir", type="string", length=255, nullable=true, options={"comment"="путь к каталогу src проекта"})
     */
    private $srcDir;

    /**
     * @var string|null
     *
     * @ORM\Column(name="default_namespace", type="string", length=255, nullable=true, options={"comment"="namspace по умолчанию. Альтернатива src_dir"})
     */
    private $defaultNamespace;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getUserId(): ?int
    {
        return $this->userId;
    }

    public function setUserId(?int $userId): self
    {
        $this->userId = $userId;

        return $this;
    }

    public function getJson(): ?string
    {
        return $this->json;
    }

    public function setJson(?string $json): self
    {
        $this->json = $json;

        return $this;
    }

    public function getClassNameIdx(): ?int
    {
        return $this->classNameIdx;
    }

    public function setClassNameIdx(?int $classNameIdx): self
    {
        $this->classNameIdx = $classNameIdx;

        return $this;
    }

    public function getSrcDir(): ?string
    {
        return $this->srcDir;
    }

    public function setSrcDir(?string $srcDir): self
    {
        $this->srcDir = $srcDir;

        return $this;
    }

    public function getDefaultNamespace(): ?string
    {
        return $this->defaultNamespace;
    }

    public function setDefaultNamespace(?string $defaultNamespace): self
    {
        $this->defaultNamespace = $defaultNamespace;

        return $this;
    }


}
