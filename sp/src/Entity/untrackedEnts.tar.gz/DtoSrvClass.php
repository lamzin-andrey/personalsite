<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DtoSrvClass
 *
 * @ORM\Table(name="dto_srv_class", indexes={@ORM\Index(name="task_id", columns={"task_id"})})
 * @ORM\Entity
 */
class DtoSrvClass
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int|null
     *
     * @ORM\Column(name="task_id", type="integer", nullable=true, options={"comment"="Ссылка на задачу"})
     */
    private $taskId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="className", type="string", length=255, nullable=true, options={"comment"="Имя класса, например Class_1_Dto. Может быть отредактировано пользователем"})
     */
    private $classname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="originalClassName", type="string", length=255, nullable=true, options={"comment"="Имя класса, сгенерированное при парсинге JSON. Например Class_1_Dto. Не может быть отредактировано пользователем"})
     */
    private $originalclassname;

    /**
     * @var string|null
     *
     * @ORM\Column(name="json", type="text", length=65535, nullable=true, options={"comment"="JSON объекта, из которого генерируется данный класс"})
     */
    private $json;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="hasSubObjects", type="boolean", nullable=true, options={"default"="1","comment"="Надо определять, можно ли этот класс передавать пользователю для редактирования. Если не уимеет - сразу можно"})
     */
    private $hassubobjects = '1';

    /**
     * @var bool|null
     *
     * @ORM\Column(name="hasUnsavedSubObject", type="boolean", nullable=true, options={"default"="1","comment"="Примет false когда все вложенные простые (не имеющие sub-объектов) DTO сохранены"})
     */
    private $hasunsavedsubobject = '1';

    /**
     * @var bool|null
     *
     * @ORM\Column(name="default_null", type="boolean", nullable=true, options={"default"="1","comment"="Поля класса  будут предварены символом ? и им будет присвоен null"})
     */
    private $defaultNull = '1';

    /**
     * @var bool|null
     *
     * @ORM\Column(name="implements_json_serializable", type="boolean", nullable=true, options={"default"="1","comment"="Поля класса  будут предварены символом ? и им будет присвоен null"})
     */
    private $implementsJsonSerializable = '1';

    /**
     * @var string|null
     *
     * @ORM\Column(name="src_dir", type="string", length=255, nullable=true, options={"comment"="путь к каталогу src проекта"})
     */
    private $srcDir;

    /**
     * @var string|null
     *
     * @ORM\Column(name="default_namespace", type="string", length=255, nullable=true, options={"comment"="namspace по умолчанию. Альтернатива src_dir"})
     */
    private $defaultNamespace;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTaskId(): ?int
    {
        return $this->taskId;
    }

    public function setTaskId(?int $taskId): self
    {
        $this->taskId = $taskId;

        return $this;
    }

    public function getClassname(): ?string
    {
        return $this->classname;
    }

    public function setClassname(?string $classname): self
    {
        $this->classname = $classname;

        return $this;
    }

    public function getOriginalclassname(): ?string
    {
        return $this->originalclassname;
    }

    public function setOriginalclassname(?string $originalclassname): self
    {
        $this->originalclassname = $originalclassname;

        return $this;
    }

    public function getJson(): ?string
    {
        return $this->json;
    }

    public function setJson(?string $json): self
    {
        $this->json = $json;

        return $this;
    }

    public function getHassubobjects(): ?bool
    {
        return $this->hassubobjects;
    }

    public function setHassubobjects(?bool $hassubobjects): self
    {
        $this->hassubobjects = $hassubobjects;

        return $this;
    }

    public function getHasunsavedsubobject(): ?bool
    {
        return $this->hasunsavedsubobject;
    }

    public function setHasunsavedsubobject(?bool $hasunsavedsubobject): self
    {
        $this->hasunsavedsubobject = $hasunsavedsubobject;

        return $this;
    }

    public function getDefaultNull(): ?bool
    {
        return $this->defaultNull;
    }

    public function setDefaultNull(?bool $defaultNull): self
    {
        $this->defaultNull = $defaultNull;

        return $this;
    }

    public function getImplementsJsonSerializable(): ?bool
    {
        return $this->implementsJsonSerializable;
    }

    public function setImplementsJsonSerializable(?bool $implementsJsonSerializable): self
    {
        $this->implementsJsonSerializable = $implementsJsonSerializable;

        return $this;
    }

    public function getSrcDir(): ?string
    {
        return $this->srcDir;
    }

    public function setSrcDir(?string $srcDir): self
    {
        $this->srcDir = $srcDir;

        return $this;
    }

    public function getDefaultNamespace(): ?string
    {
        return $this->defaultNamespace;
    }

    public function setDefaultNamespace(?string $defaultNamespace): self
    {
        $this->defaultNamespace = $defaultNamespace;

        return $this;
    }


}
