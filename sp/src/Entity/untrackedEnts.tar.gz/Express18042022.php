<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Express18042022
 *
 * @ORM\Table(name="express_18042022")
 * @ORM\Entity
 */
class Express18042022
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="numbers", type="text", length=65535, nullable=true)
     */
    private $numbers;

    /**
     * @var string|null
     *
     * @ORM\Column(name="astr", type="string", length=64, nullable=true)
     */
    private $astr;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created_time", type="datetime", nullable=true)
     */
    private $createdTime;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumbers(): ?string
    {
        return $this->numbers;
    }

    public function setNumbers(?string $numbers): self
    {
        $this->numbers = $numbers;

        return $this;
    }

    public function getAstr(): ?string
    {
        return $this->astr;
    }

    public function setAstr(?string $astr): self
    {
        $this->astr = $astr;

        return $this;
    }

    public function getCreatedTime(): ?\DateTimeInterface
    {
        return $this->createdTime;
    }

    public function setCreatedTime(?\DateTimeInterface $createdTime): self
    {
        $this->createdTime = $createdTime;

        return $this;
    }


}
