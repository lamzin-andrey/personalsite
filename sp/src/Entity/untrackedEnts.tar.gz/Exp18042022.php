<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Exp18042022
 *
 * @ORM\Table(name="exp_18042022")
 * @ORM\Entity
 */
class Exp18042022
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="value", type="string", length=1024, nullable=true)
     */
    private $value;

    /**
     * @var string|null
     *
     * @ORM\Column(name="astr", type="string", length=64, nullable=true)
     */
    private $astr;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="created_time", type="datetime", nullable=true)
     */
    private $createdTime;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getValue(): ?string
    {
        return $this->value;
    }

    public function setValue(?string $value): self
    {
        $this->value = $value;

        return $this;
    }

    public function getAstr(): ?string
    {
        return $this->astr;
    }

    public function setAstr(?string $astr): self
    {
        $this->astr = $astr;

        return $this;
    }

    public function getCreatedTime(): ?\DateTimeInterface
    {
        return $this->createdTime;
    }

    public function setCreatedTime(?\DateTimeInterface $createdTime): self
    {
        $this->createdTime = $createdTime;

        return $this;
    }


}
