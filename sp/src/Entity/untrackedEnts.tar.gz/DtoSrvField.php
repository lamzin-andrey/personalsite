<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DtoSrvField
 *
 * @ORM\Table(name="dto_srv_field", indexes={@ORM\Index(name="class_id", columns={"class_id"})})
 * @ORM\Entity
 */
class DtoSrvField
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int|null
     *
     * @ORM\Column(name="class_id", type="integer", nullable=true, options={"comment"="К какому классу относится поле. Ссылка на таблицу классов."})
     */
    private $classId;

    /**
     * @var int|null
     *
     * @ORM\Column(name="type_class_id", type="integer", nullable=true, options={"comment"="Какого класса поле. Ссылка на таблицу классов."})
     */
    private $typeClassId;

    /**
     * @var string|null
     *
     * @ORM\Column(name="class_name", type="string", length=255, nullable=true, options={"comment"="Имя класса. Учитывается в том случае, если пользователь захочет указать класс, которого нет среди сгенерированных в ходе парсинга. "})
     */
    private $className;

    /**
     * @var string|null
     *
     * @ORM\Column(name="type_name", type="string", length=255, nullable=true, options={"comment"="Имя типа. Для простых типов."})
     */
    private $typeName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true, options={"comment"="Имя поля класса"})
     */
    private $name;

    /**
     * @var bool|null
     *
     * @ORM\Column(name="is_list", type="boolean", nullable=true, options={"comment"="1 - поле содержит массив классов"})
     */
    private $isList;

    /**
     * @var string|null
     *
     * @ORM\Column(name="json", type="text", length=65535, nullable=true, options={"comment"="JSON объекта, из которого генерируется данный класс. Если поле имеет простой тип, пусто."})
     */
    private $json;

    /**
     * @var int|null
     *
     * @ORM\Column(name="class_name_idx", type="integer", nullable=true, options={"comment"="Число в сгенерированом имени класса, например Class_1_Dto"})
     */
    private $classNameIdx;

    /**
     * @var string|null
     *
     * @ORM\Column(name="src_dir", type="string", length=255, nullable=true, options={"comment"="путь к каталогу src проекта"})
     */
    private $srcDir;

    /**
     * @var string|null
     *
     * @ORM\Column(name="default_namespace", type="string", length=255, nullable=true, options={"comment"="namspace по умолчанию. Альтернатива src_dir"})
     */
    private $defaultNamespace;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getClassId(): ?int
    {
        return $this->classId;
    }

    public function setClassId(?int $classId): self
    {
        $this->classId = $classId;

        return $this;
    }

    public function getTypeClassId(): ?int
    {
        return $this->typeClassId;
    }

    public function setTypeClassId(?int $typeClassId): self
    {
        $this->typeClassId = $typeClassId;

        return $this;
    }

    public function getClassName(): ?string
    {
        return $this->className;
    }

    public function setClassName(?string $className): self
    {
        $this->className = $className;

        return $this;
    }

    public function getTypeName(): ?string
    {
        return $this->typeName;
    }

    public function setTypeName(?string $typeName): self
    {
        $this->typeName = $typeName;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getIsList(): ?bool
    {
        return $this->isList;
    }

    public function setIsList(?bool $isList): self
    {
        $this->isList = $isList;

        return $this;
    }

    public function getJson(): ?string
    {
        return $this->json;
    }

    public function setJson(?string $json): self
    {
        $this->json = $json;

        return $this;
    }

    public function getClassNameIdx(): ?int
    {
        return $this->classNameIdx;
    }

    public function setClassNameIdx(?int $classNameIdx): self
    {
        $this->classNameIdx = $classNameIdx;

        return $this;
    }

    public function getSrcDir(): ?string
    {
        return $this->srcDir;
    }

    public function setSrcDir(?string $srcDir): self
    {
        $this->srcDir = $srcDir;

        return $this;
    }

    public function getDefaultNamespace(): ?string
    {
        return $this->defaultNamespace;
    }

    public function setDefaultNamespace(?string $defaultNamespace): self
    {
        $this->defaultNamespace = $defaultNamespace;

        return $this;
    }


}
