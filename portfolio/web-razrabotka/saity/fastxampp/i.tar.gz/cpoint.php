<?php
function cpoint($msg = '', $cmd = '') {
	global $dbg_start_time, $dbg_total_start_time;
	if ($cmd == 'set') {
		if (!$dbg_total_start_time) {
			$dbg_total_start_time = microtime(true);
		}
		$dbg_start_time = microtime(true);
		if ($msg) {
			print "{$msg}\n";
		}
	} else {
		$time = microtime(true) - $dbg_start_time;
		print $msg . ': ' . "{$time}\n";
		if ($cmd == 'total') {
			$time = microtime(true) - $dbg_total_start_time;
			print 'Total: ' . "{$time}\n";
		}
	}
}