<?php
/**
 * @desc Класс реализует анализатор XML файлов в формате YandexML
 * **/
class Yml_Parser {
	/** Сколько считать блоков offer из файла*/
	const OFFERS_PER_BLOCK = 4000;
	/** Объект приложения */
	public $app;
	/** Каталог временных файлов */
	private $_tmp_dir;
	/** Каталог лог файлов */
	private $_log_dir;
	/** Каталог загруженных файлов */
	private $_yml_dir;
	/** Кодировка обрабатываемого файла */
	private $_encoding = 'UTF-8';
	/** Целевая кодировка */
	private $_target_encoding = 'UTF-8';
	/** Файл хранящий последнее состояние процесса - 
	 * имя xml файла, -- по идее всегда будет совпадать с id, но лучше перестраховаться
	 * id его записи в БД,
	 * offer_id его записи в БД,
	 * смещение от его начала
	 * режим работы парсера, 0 - режим парсинга файла, 1 - режим установки флага  is_deleted_in_source
	 * флаг, в зависимости от которого запускается режим установки флага  is_deleted_in_source  0- во время парсинга файла не было выполнено ни одного update products, 1 - было update products
	 
	 * (шесть цифр в четырех строках)*/
	private $_last_state_file;
	/** Валюты текущего XML каталога */
	private $_currencies;
	/** Категории текущего XML каталога */
	private $_categories;
	/** Идентификатор оффера текущего XML каталога */
	private $_offer_id;
	/** Идентификатор текущего XML каталога */
	private $_xmlfeeds_id;
	/** Количество товаров с неопределенной категорией */
	private $_quantityUndefinedCategories = 0;
	/** Категории, которые присвоены товару, но которых нет в дереве категорий исходного xml файла*/
	private $_productUndefinedCategoriesIds = array();
	/** Если true следует по завершению анализа xml перейти к установке флага products.is_deleted_in_source*/
	private $_update_flag = false;
	/** Если 0 следует выполнить анализ xml, 1  - перейти к установке флага products.is_deleted_in_source*/
	private $_mode = 0;
	/**
	 *@desc Конструктор
	 *@param $app объект приложения
	 *@param $tmp_dir путь к каталогу временных файлов
	 *@param $log_dir путь к каталогу логов
	**/
	public function __construct($app, $tmp_dir, $log_dir) {
		$this->app = $app;
		$this->_tmp_dir = $tmp_dir;
		$this->_log_dir = $log_dir;
		$this->_yml_dir = $app['config']['offers.data'] . '/xml';
		$this->_last_state_file = $this->_tmp_dir . '/last_state.state';
	}
	/**
	 *@desc Запуск процесса парсинга
	 *@param $pid_path Путь к файлу процесса
	**/
	public function run($pid_path) {
		$app = $this->app;
		if (Cron_Funcs::startCron($pid_path)) {
			die('Cron is running');
		}
		$rec_id = $this->_getTask($file_path, $offset, $offer_id);
		if ($rec_id) {
			$this->_offer_id = $offer_id;
			$this->_xmlfeeds_id= $rec_id;
			if ($this->_mode == 0) {
				$this->_getEncoding($file_path);
				$this->_parse($file_path, $rec_id, $offset, $offer_id);
			} else if ($this->_mode == 1) {
				$this->_resetIsDeleteInSourceFlag($rec_id, $offset);
			}
		}
		Cron_Funcs::stopCron($pid_path);
	
	}
	/**
	 *@desc Получить кодировку файла
	 *@param $path Путь к xml файлу 
	**/
	private function _getEncoding($file_path) {
		if ( !file_exists($file_path) ) {
			$msg = "Не найден xml файл на сервере. File {$file_path} not exists";
			$this->_breakStateFile();
			$this->app['DB']->useConnection();
			$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
			$this->app['DB']->closeConnection();
			$this->_error_log($msg);
			throw new Exception($msg);
		}
		$h = fopen($file_path, 'r');
		$pattern = "#encoding=[\"']{1}([a-zA-Z\-0-9]*)[\"']#";
		$break = 0;
		while (true) {
			$s = fgets($h);
			if (preg_match($pattern, $s, $m) && isset($m[1])) {
				$encoding = $m[1];
				$this->_encoding = StrFuncs::app_strtoupper($encoding);
				break;
			}
			$break++;
			if ($break > 10) {
				$msg = "Не найдено определение кодировки в файле {$file_path} в первых 10 строках";
				$this->_breakStateFile();
				$this->app['DB']->useConnection();
				$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
				$this->app['DB']->closeConnection();
				$this->_error_log($msg);
				throw new Exception($msg);
			}
		}
	}
	/**
	 *@desc Проверяет, завершена ли последняя задача, то есть закончен ли парсинг последнего файла (мог быть незапланировано прерван)
	 *      Если последняя задача была завершена, берет из offers_xmlfeeds первую модерированую но не анализированую запись. 
	 *      Если все анализированы, берет первую модерированую с указанным url,
 	 *		скачивает файл, если md5 сум вновь закаченного не совпадает со старым, 
 	 *		помечает ее как неанализированную и возвращает ее идентификатор
 	 *@param string &$file_path сюда записывается путь к файлу в случае не нулевого id
 	 *@param int &$offset сюда записывается смещение относительно начала файла
 	 *@param int &$offer_id сюда записывается идентификатор оффера, чтобы лишний раз не дергать базу
	 *@return int Возвращает id записи в xml_feeds или 0. Если вернула не 0, значит надо тупо брать файл указанный в записи и парсить
	**/
	private function _getTask(&$file_path, &$offset, &$offer_id) {
		$xml_dir = $this->_yml_dir;
		$tmp_dir = $this->_tmp_dir;
		$db = $this->app['DB'];
		if (!file_exists($this->_last_state_file)) {
			$this->_breakStateFile();
			chmod($this->_last_state_file, 0766); //чтобы дать доступ к файлу php процессам запущеным при HTTP запросах 
		}
		
		//$a_last_state = explode("\n", file_get_contents($this->_last_state_file));
		if ($this->_readStateFile($file_path, $file_id, $offer_id, $offset, $mode, $count_update, $error_msg)) {
			/*$file_path   = $xml_dir . '/' . (int)$a_last_state[0] . '.xml';
			$file_id     = (int)$a_last_state[1];
			$offer_id     = (int)$a_last_state[2];
			$offset = (int)$a_last_state[3];*/
			if ($file_id) { //значит, есть незаконченный файл, надо его закончить
				return $file_id;
			} else {
				$this->app['DB']->useConnection();
				$query = 'SELECT oxf.id, oxf.offer_id, oxf.url, oxf.md5 FROM offers_xmlfeeds AS oxf 
							LEFT JOIN offers AS o ON oxf.offer_id = o.id 
							WHERE o.status != '. OfferStatus::DELETED .'
								AND oxf.status = 2 AND (oxf.parsing_status = 1 OR oxf.parsing_status = 0)  
							LIMIT 1';
				$rows = $db->runQuery($query);
				if (!$rows) {
					$query = 'SELECT oxf.id, oxf.offer_id, oxf.url, oxf.md5 FROM offers_xmlfeeds AS oxf
								LEFT JOIN offers AS o ON oxf.offer_id = o.id  
								WHERE o.status != '. OfferStatus::DELETED .' AND oxf.status = 2 AND oxf.parsing_status = 2 AND (oxf.url IS NOT NULL OR oxf.url != \'\') '
                                                . 'AND NOW() - last_complete_parse_date > \'24 hour\'::interval '
                                                . 'ORDER BY last_complete_parse_date ASC';
					$rows = $db->runQuery($query);
				}
				$this->app['DB']->closeConnection();
				if ($rows) {
					foreach ($rows as $row) {
						if ($row['url']) {
							$tmp_file_path = $this->_download($row['url'], $row['id']);
							if ($tmp_file_path === false || !file_exists($tmp_file_path)) {
								$this->_error_log("Не могу скачать YML файл {$row['url']}");
								//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
								$this->_breakStateFile();
								$this->app['DB']->useConnection();
								$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $row['id']);
								$this->app['DB']->closeConnection();
								throw new Exception("Fail download YML file {$row['url']}");
								return 0;
							}
							$md5 = md5_file($tmp_file_path);
							if ($md5 == $row['md5']) {
								unlink($tmp_file_path);
								$this->app['DB']->useConnection();
								$this->app['DB']->update('offers_xmlfeeds', array('parsing_status' => 2), ' id = ' . $row['id']);
								$this->app['DB']->closeConnection();
								continue;
							} else {
								if (!copy($tmp_file_path, $xml_dir . '/' . (int)$row['id'] . '.xml') ) {
									$this->_error_log("Fail copy downloaded YML file from {$tmp_file_path} to " . $xml_dir . '/' . (int)$row['id'] . '.xml');
									throw new Exception("Fail copy downloaded YML file from {$tmp_file_path} to " . $xml_dir . '/' . (int)$row['id'] . '.xml');
									return 0;
								}
								unlink($tmp_file_path);
							}
						} else {
							$md5 = md5_file( $xml_dir . '/' . (int)$row['id'] . '.xml' );
						}
						$data = array('parsing_status' => 1, 'md5' => $md5);
						$where = ' id =  '. $row['id'];
						$this->app['DB']->useConnection();
						$db->update('offers_xmlfeeds', $data, $where);
						$this->app['DB']->closeConnection();
						//file_put_contents($this->_last_state_file, "{$row['id']}\n{$row['id']}\n{$row['offer_id']}\n0");
						$this->_writeStateFile($row['id'], $row['id'], $row['offer_id'], 0, 0, 0);
						$file_path = $xml_dir . '/' . (int)$row['id'] . '.xml';
						$offset = 0;
						$offer_id = $row['offer_id'];
						return $row['id'];
					}
				} else {
					return 0;
				} 
			}
		} else {
			$this->_breakStateFile();
			$this->_getTask($file_path, $offset, $offer_id);
		}
		return 0;
	}
	/**
	 *@desc Парсит файл $file_path от позиции $offset. Состояние записывает в $_tmp_dir/file_name.state или в БД при достижении конца файла
	 *@param string $file_path путь к [скачанному ранее удаленному] файлу
	 *@param int $rec_id идентификатор записи соответствующей файлу в таблице offers_xmlfeeds
 	 *@param int $offset смещение относительно начала файла
 	 *@param int $offer_id идентификатор оффера
	**/
	private function _parse($file_path, $rec_id, $offset, $offer_id) {
		$db = $this->app['DB'];
		if ( !file_exists($file_path) ) {
			$this->_error_log("File {$file_path} not exists");
			//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
			$this->_breakStateFile();
			throw new Exception("File {$file_path} not exists");
		}
		if ($offset == 0) {
			$offset = $this->_parseCurrenciesAndCategories($file_path, $rec_id, $offer_id); //сохранить категории данного файла в базу и загрузить в приватный массив;
			$this->app['DB']->useConnection();
			$db->update('offers_xmlfeeds', array('quantity_products' => 0), ' id = ' . $this->_xmlfeeds_id);
			//$db->update('products', array('is_deleted_in_source' => 'TRUE'), ' xml_catalog_id =  ' . $this->_xmlfeeds_id);
			$this->app['DB']->closeConnection();
		} else {
			$this->_loadXmlFeedsCurrenciesAndCategories(); //загрузить категории данного файла из базы в приватный массив;
		}
		$h = fopen($file_path, 'r');
		fseek($h, $offset);
		while (true) {
			$old_offset = $offset;
			$s = $this->_readOffersFromXml($h, $offset, $is_eof);//считать несколько секций offer
			if ($offset < $old_offset) {
				$msg = 'Похоже произошло переполнение переменной  offset file ' . __FILE__  . ', line ' . __LINE__;
				$this->_error_log($msg);
				throw new Exception($msg);
			}
			if ($s == '') {
				break;
			}
			$count_update = $this->_processOffersXml($s, $rec_id, $file_path, $offer_id);
			if ($this->_update_flag) {
				$count_update = 1; 
			}
			if ($count_update) {
				$this->_update_flag = true; 
			}
			if ($is_eof) {
				//изменить тип задачи
				if (!$this->_update_flag) {
					//записать в базу и файл состояния, что анализ закончен
					$this->_endParse($rec_id);
				} else {
					$this->_readStateFile($file_path, $file_id, $offer_id, $offset, $mode, $count_update, $error_msg);
					$this->_writeStateFile($this->_xmlfeeds_id, $this->_xmlfeeds_id, $offer_id, 0, 1, $count_update);
				}
				//
				break;
			} else {
				$this->app['DB']->useConnection();
				$this->app['DB']->update('offers_xmlfeeds', array('parsing_status' => 1), 'id = ' . $rec_id);
				$this->app['DB']->closeConnection();
				//записать в файл состояние
				//file_put_contents($this->_last_state_file, "{$rec_id}\n{$rec_id}\n{$offer_id}\n{$offset}");
				$this->_writeStateFile($rec_id, $rec_id, $offer_id, $offset, 0, ($count_update ? '1' : '0'));
			}
		}
		fclose($h);
	}
	/**
	 *@desc Считать из файла $h количество офферов равное self::OFFERS_PER_BLOCK 
	 *@param  handle $h указатель на открытый файл
	 *@param  int    &$offset смещение от начала файла
	 *@param  bool   &$is_eof принимает true если достигнут конец файла 
	 *@return string считаный из файла текст
	**/
	private function _readOffersFromXml($h, &$offset, &$is_eof) {
		$buf = '';
		$limit = self::OFFERS_PER_BLOCK;
		$count = 0;
		$tag_is_open = false;
		$is_eof = false;
		while (!feof($h)) {
			$s = fgets($h);
			$offset += strlen($s);
			$offers_pos = StrFuncs::app_strpos($s, '<offers>');
			$offer_pos = StrFuncs::app_strpos($s, '<offer');
			$variant_1 = ($offers_pos === false && $offer_pos !== false);
			$variant_2 = ((int)$offers_pos < (int)$offer_pos);
			if ( $variant_1 || $variant_2 ) {
				$tag_is_open = true;
			}
			if ($tag_is_open) {
				$buf .= $s;
			}
			if ( StrFuncs::app_strpos($s, '</offer>') !== false) {
				$count++;
				$tag_is_open = false;
			}
			if ($count == $limit) {
				break;
			}
			$is_eof = feof($h);
		}
		return "<parserdata>$buf</parserdata>";
	}
	/**
	 *@desc   Парсим через DOM, создание DOM, вставка в базу
	 *@param  string $s фрагмент xml содержащий один или несколько тегов <offer></offer>
	 *@param  int $rec_id номер записи из таблицы offers_xmlfeeds
	 *@param  string $file_path путь к файлу
	 *@return 
	**/
	/**
	 *@desc   Парсим через DOM, создание DOM, вставка в базу
	 *@param  string $s фрагмент xml содержащий один или несколько тегов <offer></offer>
	 *@param  int $rec_id номер записи из таблицы offers_xmlfeeds
	 *@param  string $file_path путь к файлу
	 *@return int количество обновленных записей
	 **/
	private function _processOffersXml($s, $rec_id, $file_path, $offer_id) {
		if ($this->_encoding != $this->_target_encoding) {
			$s = mb_convert_encoding($s, $this->_target_encoding, $this->_encoding);
		}
		$db = $this->app['DB'];
		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->validateOnParse = false;
		$doc->loadXML($s);
		$config = $this->app['config'];
		$offers = $doc->getElementsByTagName('offer');
		$a_offers = array();
		$sql_values = array(); //array for inser values collect
		$sql_values_groups = array();
		$sql_fields = '';
		$src_ids = array();
		for ($j = 0; $j < $offers->length; $j++) {
			$offer = $offers->item($j);
			$item = array( 'other_options' => array() );
			$item['src_product_id'] = $this->_getAttribute($offer, 'id', true);
			$src_ids[ $item['src_product_id'] ] = $item['src_product_id'];
			$item['other_options']['available'] = $this->_getAttribute($offer, 'available') == 'true' ? 'TRUE' : ($this->_getAttribute($offer, 'available') == 'false' ? 'FALSE' : NULL);
			$item['offer_type'] = $this->_getAttribute($offer, 'type');
			$item['campaing_id'] = $this->_getCampaingIdByName( $this->_getTag($offer, 'advcampaign_name') );
			$item['price'] = $this->_getTag($offer, 'price', 'float');
			$currency_id = $this->_getTag($offer, 'currencyId');
			if ( isset( $this->_currencies[$currency_id] ) ) {
				$item['other_options']['currency'] = $this->_currencies[$currency_id]->our_currency_code ? $this->_currencies[$currency_id]->our_currency_code :$this->_currencies[$currency_id];
				$item['other_options']['currency_rate'] = $this->_currencies[$currency_id]->rate ? $this->_currencies[$currency_id]->rate : 1;
			} elseif( isset( $config['currency.map'][$currency_id] ) ) {
				$item['other_options']['currency'] = $config['currency.map'][$currency_id];
				$item['other_options']['currency_rate'] = 1;//по умолчанию
			} else {
				$msg = 'Unknown currency Id ' . $currency_id . ' in ' . $file_path . ', offer id = ' . $item['src_product_id'];
				$this->_error_log($msg);
				$this->app['DB']->useConnection();
				$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
				$this->app['DB']->closeConnection();
				//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
				$this->_breakStateFile();
				throw new Exception($msg);
			}
				
			$src_category = $this->_getTag($offer, 'categoryId', 'int');
			if (!isset($this->_categories[$src_category])) {
				//запоминаем id не найденной категории
				$this->_productUndefinedCategoriesIds[] = $src_category;
				//увеличиваем значение счетчика товаров с неопределенной категорией
				$this->_quantityUndefinedCategories++;
				continue;
			}
			$item['src_cat_id'] = $this->_categories[$src_category] ['id'];
			$item['cat_id'] = $this->_categories[$src_category]['our_cat_id'];
			$item['xml_catalog_id'] = $rec_id;
			$item['other_options']['store'] = $this->_getTag($offer, 'store', 'bool');
			$item['other_options']['pickup'] = $this->_getTag($offer, 'pickup', 'bool');
			$item['other_options']['delivery'] = $this->_getTag($offer, 'delivery', 'bool');
			$item['other_options']['url'] = $this->_getTag($offer, 'url', 'bool');
			$item['vendor'] = $this->_getTag($offer, 'vendor');
			$item['name'] = $this->_getTag($offer, 'name');
			$item['description'] = $this->_getTag($offer, 'description');
			$item['offer_id'] = $offer_id;
			$modified_time = $this->_getTag($offer, 'modified_time', 'float');
			if ($modified_time) {
				$item['modified_time'] = date('Y-m-d H:i:s', $modified_time);
			} else {
				$item['modified_time'] = date('Y-m-d H:i:s');
			}
			//picturies
			$picturies = $offer->getElementsByTagName('picture');
			$a_picts = array();
			for ($i = 0; $i < $picturies->length; $i++) {
				$a_picts[] = str_replace( array('<![CDATA[', ']]>'), array('', ''), $picturies->item($i)->textContent);
			}
			$item['photos'] = json_encode($a_picts);
			if (count($a_picts)) {
				$item['photo_exists'] = 'TRUE';
			} else {
				$item['photo_exists'] = 'FALSE';
			}
			//params
			$params = $offer->getElementsByTagName('param');
			$a_params = array();
			for ($i = 0; $i < $params->length; $i++) {
				$p = $params->item($i);
				$param = array();
				$param['textContent'] = str_replace( array('<![CDATA[', ']]>'), array('', ''), $params->item($i)->textContent);
				$this->_getAllTagAttributes($p, $param);
				$a_params[] = $param;
			}
			$item['options'] = json_encode($a_params);
			$this->_grabUnknownTags($offer, $item['other_options'], $item);
			$item['other_options'] = json_encode($item['other_options']);
			$a_offers[ $item['src_product_id'] ] = $item;
			if ( !$sql_fields) {
				$sql_fields = '(' . join(', ', array_keys($item) ) . ')';
			}
			
			$sql_values[ $item['src_product_id'] ] = array();
			$sql_values[ $item['src_product_id'] ][] =  $item['other_options'];
			$sql_values[ $item['src_product_id'] ][] =  $item['src_product_id'];
			$sql_values[ $item['src_product_id'] ][] =  $item['offer_type'];
			$sql_values[ $item['src_product_id'] ][] =  $item['campaing_id'];
			$sql_values[ $item['src_product_id'] ][] =  $item['price'];
			$sql_values[ $item['src_product_id'] ][] =  $item['src_cat_id'];
			$sql_values[ $item['src_product_id'] ][] =  $item['cat_id'];
			$sql_values[ $item['src_product_id'] ][] =  $item['xml_catalog_id'];
			$sql_values[ $item['src_product_id'] ][] =  $item['vendor'];
			$sql_values[ $item['src_product_id'] ][] =  $item['name'];
			$sql_values[ $item['src_product_id'] ][] =  $item['description'];
			$sql_values[ $item['src_product_id'] ][] =  $item['offer_id'];
			$sql_values[ $item['src_product_id'] ][] =  (isset($item['modified_time']) ? $item['modified_time'] : null);
			$sql_values[ $item['src_product_id'] ][] =  $item['photos'];
			$sql_values[ $item['src_product_id'] ][] =  $item['photo_exists'];
			$sql_values[ $item['src_product_id'] ][] =  $item['options'];
			$sql_values_groups[ $item['src_product_id'] ] = '(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
			
		}// end for
		return $this->_addNewOffers($sql_values, $a_offers, $src_ids, $rec_id, $sql_fields, $sql_values_groups);
	}
	/**
	 * @desc Вставка или обновление существующих данных о товарах из каталога $rec_id
	 * @param  array $sql_values массив с данными, подготовленными для вставки insert запросом @see _processOffersXml
	 * @param  array $a_offers   массив с данными о товарах, используется при выполнении update запросов
	 * @param  array $src_ids    массив с данными об исходных идентификаторах товаров из каталога rec_id, для предотвращения дублей
	 * @param  array $rec_id     идентификатор каталога в offers_xmlfeeds
	 * @param  array $sql_fields поля таблицы products, которые вставляем
	 * @param  array $sql_values_group вспомогательный массив
	 * @return int количество обновленных записей
	**/
	private function _addNewOffers($sql_values, $a_offers, $a_src_ids, $rec_id, $sql_fields, $sql_values_groups) {
		$db = $this->app['DB'];
		$insert_query = 'INSERT INTO products {FIELDS} VALUES {VALUES}';
		$count = 0;
		$count_update = 0;
		if ( count($sql_values) ) {
			//смотрим, есть ли в таблице продуктов с такими исходными номерами и таким идентификаторами каталога
			//если нет, вставляем одним запросом, иначе вставляем каждый по отдельности
			$src_ids = join(',', $a_src_ids);
			$query = "SELECT id, src_product_id, photos FROM products WHERE xml_catalog_id = ? AND src_product_id IN ({$src_ids})";
			$this->app['DB']->useConnection();
			$existData = $db->runQuery($query, array($rec_id));
			$this->app['DB']->closeConnection();
			if (is_array($existData) && count($existData)) {
				foreach ($existData as $row) {
					$a_offers[ $row['src_product_id'] ]['is_deleted_in_source'] = 'FALSE';
					//print_r( $a_offers[ $row['src_product_id'] ] );
					$photos = json_decode($row['photos']);
					if (!(is_array($photos) && count($photos) == 0)) {
						unset( $a_offers[ $row['src_product_id'] ]['photos'] );
					}
					$this->app['DB']->useConnection();
					$db->update('products', $a_offers[ $row['src_product_id'] ], ' id =  ' . $row['id']);
					$db->insert('tmp_products_data', array('src_product_id'=> $row['src_product_id'], 'xml_catalog_id' => $this->_xmlfeeds_id ), false);
					$this->app['DB']->closeConnection();
					$count_update++;
					if ($db->numAffectedRows()) {
						$count++;
					}
					unset($a_offers[ $row['src_product_id'] ]);
					unset($a_src_ids[ $row['src_product_id'] ]);
					//print "try unset {$row['src_product_id']}";
					unset($sql_values[ $row['src_product_id'] ]);
					unset($sql_values_groups[ $row['src_product_id'] ]);
				}
			}
			//print_r($sql_values);
			//print("count = {$count}\n");
			$insert_count = count($sql_values);
			if ( $insert_count ) {
				$insert_query = StrFuncs::app_str_replace('{FIELDS}', $sql_fields, $insert_query);
				$insert_query = StrFuncs::app_str_replace('{VALUES}', join(', ', $sql_values_groups), $insert_query);
				$this->app['DB']->useConnection();
				$params = array();
				$params_for_tmp_data = array();
				$placeholders_for_tmp_data = array(); //'(?,?),)(?,?)[,...]' для второго запроса 
				foreach ($sql_values as $src_product_id => $row) {
					$params = array_merge($params, $row);
					$params_for_tmp_data[] = $this->_xmlfeeds_id;
					$params_for_tmp_data[] = $src_product_id;
					$placeholders_for_tmp_data[] = '(?,?)';
				}
				$db->runQuery($insert_query, $params);
				$this->app['DB']->closeConnection();
				
				$tmp_products_data_query = 'INSERT INTO tmp_products_data (xml_catalog_id, src_product_id) VALUES ' . join(',', $placeholders_for_tmp_data);
				$this->app['DB']->useConnection();
				$db->runQuery($tmp_products_data_query, $params_for_tmp_data);
				$this->app['DB']->closeConnection();
				
				$count += $insert_count;
			}
		}
		$this->app['DB']->useConnection();
		$db->runQuery("UPDATE offers_xmlfeeds SET quantity_products = quantity_products + {$count} WHERE id = {$this->_xmlfeeds_id}");
		$this->app['DB']->closeConnection();
		//die('test');
		return $count_update;
	}
	
	/**
	 *@desc Возвращает идентификатор записи из таблицы product_campaings, если записи не существует, вставляет новую 
	 *@param $campaing_name
	 *@return int
	**/
	private function _getCampaingIdByName($campaing_name) {
		if (!$campaing_name) {
			return 0;
		}
		$db = $this->app['DB'];
		$this->app['DB']->useConnection();
		$query = 'SELECT id FROM product_campaings WHERE name = ? LIMIT 1';
		$id = (int)$db->getValue($query, array($campaing_name));
		$this->app['DB']->closeConnection();
		if (!$id) {
			$this->app['DB']->useConnection();
			$id = $db->insert('product_campaings', array('name' => $campaing_name), true);
			$this->app['DB']->closeConnection();
		}
		return $id;
	}
	/**
	 *@desc Вспомогательная функция получения textContent DOM ноды
	 *@param DOMNode $node - parentNode
	 *@param string  $tag_name
	 *@param string  $type 'int'|'float'|'bool'|'text' (default 'text')
	 *@return null если ноды не существует или ее значение не определено, приведенное к указанному типу в противном случае. Для bool возвращается 't' | 'f'
	**/
	private function _getTag($node, $tag_name, $type = 'text') {
		$list = $node->getElementsByTagName($tag_name);
		if ($list->length > 0) {
			$val = $list->item(0)->textContent;
			switch ($type) {
				case 'int' :
					$val = (int)$val;
					break;
				case 'float' :
					$val = doubleval($val);
					break;
				case 'bool' :
					$val = strtolower($val);
					$val = ($val == 'true' ? 'TRUE' : ($val == 'false' ? 'FALSE': null));
					break;
				default:
					$val = str_replace( array('<![CDATA[', ']]>'), array('', ''), $val);
					$val = trim($val);
			}
			return $val;
		}
		switch ($type) {
			case 'int' :
			case 'float':
			case 'bool':
				return null;
			default:
				return '';
		}
	}
	/**
	 *@desc Вспомогательная функция получения аттрибута DOM ноды
	 *@param DOMNode $node
	 *@param string  $attrname
	 *@param bool    $to_int
	 *@return null | string | int значение атрибута, null если такгог нет
	**/
	private function _getAttribute($node, $attrname, $to_int = false) {
		if ($node->hasAttribute($attrname)) {
			$r = $node->getAttribute($attrname);
			if ($to_int) {
				$r = (int)$r;
			}
			return $r;
		}
		return null;
	}
	/**
	 *@desc   Загрузить валюты и категории из БД в $this->_categories
	 *@param  int $offer_id Идентификатор оффера
	 *@return $this->_categories
	**/
	private function _loadXmlFeedsCurrenciesAndCategories(){
		//получить все категории для данного оффера в нашей БД
		$db = $this->app['DB'];
		$this->app['DB']->useConnection();
		$query = 'SELECT * FROM xml_products_categories_data WHERE offers_xmlfeeds_id = ?';
		$raw_categories_data = $db->runQuery($query, array($this->_xmlfeeds_id));
		$this->app['DB']->closeConnection();
		$ex_categories_data = array();//существующие в базе категории
		foreach ($raw_categories_data as $row) {
			$ex_categories_data[$row['src_cat_id']] = $row;
		}
		$this->_categories = $ex_categories_data;
		$this->app['DB']->useConnection();
		$currencies_data = $db->getValue('SELECT currencies FROM offers_xmlfeeds WHERE id = ' . $this->_xmlfeeds_id . ' LIMIT 1');
		$this->app['DB']->closeConnection();
		if ($currencies_data) {
			$currencies_data = json_decode($currencies_data);
			foreach ($currencies_data as $id => $info) {
				$this->_currencies[$id] = $info;
			}
		}
		return $ex_categories_data;
	}
	/**
	 *@desc сохранить валюты и категории данного XML файла в базу и загрузить в приватный массив $_categories
	 *@param string $file_path
	 *@param int $rec_id
	 *@param int $offer_id
	 *@return int смещение от начала файла
	**/
	private function _parseCurrenciesAndCategories($file_path, $rec_id, $offer_id) {
		$offset = 0;
		$currency_complete = false;   //признаки прочтения соотв. закрывающих тегов
		$categories_complete = false;
		$currency_is_open = false;   //признаки прочтения соотв. открывающих тегов
		$categories_is_open = false;
		$buf = '';
		$h = fopen($file_path, 'r');
		$config = $app['config'];
		while (!feof($h)) {
			$s = fgets($h);
			$offset += strlen($s);//в данном случае интересует именно число байт, поэтому не надо тут app_strlen  и прочее )
			if (strpos($s, '<currencies>') !== false) {
				$currency_is_open = true;
			}
			if (strpos($s, '<categories>') !== false) {
				$categories_is_open = true;
			}
			if ($currency_is_open || $categories_is_open) {
				$buf .= $s;
			}
			if ( strpos($s, '</currencies>') !== false) {
				$currency_complete = true;
			}
			if ( strpos($s, '</categories>') !== false) {
				$categories_complete = true;
			}
			if ($categories_complete && $currency_complete) {
				break;
			}
		}
		fclose($h);
		if (!$categories_complete || !$currency_complete) {
			$msg = 'Sections "Categories" and "Currencies" not found in file "' . $file_path . '"';
			$this->_error_log($msg);
			$this->app['DB']->useConnection();
			$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
			$this->app['DB']->closeConnection();
			//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
			$this->_breakStateFile();
			throw new Exception($msg);
			return 0;
		}
		$pos_cats = strpos($buf, '</categories>');
		$pos_curr = strpos($buf, '</currencies>');
		$div = '</categories>';
		if ($pos_curr > $pos_cats) {
			$div = '</currencies>';
		}
		$data = explode($div, $buf);
		$buf = $data[0] . $div;
		$buf = "<parsercontent>$buf</parsercontent>";
		$this->_processCurrenciesAndCategoriesXml($buf, $rec_id, $offer_id, $file_path);
		return $offset;
	}
	/**
	 *@desc Парсит XML содержащий категории и валюты. Сохраняет полученные данные в БД и в приватных массивах категорий и валют
	 *@param string $str строка с XML данными
	 *@param int $id идентификатор xml_feeds.id
	 *@param int $offer_id идентификатор xml_feeds.offer_id
	 *@param string $file_path путь к файлу
	**/
	private function _processCurrenciesAndCategoriesXml($str, $id, $offer_id, $file_path) {
		$db = $this->app['DB'];
		$config = $this->app['config'];
		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->validateOnParse = false;
		if ($this->_encoding != $this->_target_encoding) {
			$str = mb_convert_encoding($str, $this->_target_encoding, $this->_encoding);
		}
		$doc->loadXML($str); //вот тут часто без собаки не обойтись
		//parseCurencies
		$aCurrencies = array();
		$currenciesBlock = $doc->getElementsByTagName('currencies');
		if ($currenciesBlock->length  > 0) {
			$currencies = $currenciesBlock->item(0)->getElementsByTagName('currency');
			if ($currencies->length  > 0) {
				for ($i = 0; $i < $currencies->length; $i++) {
					$currency = $currencies->item($i);
					$item = array();
					if ( $currency->hasAttribute('id') ) {
						$item['id'] = $currency->getAttribute('id');
					} else {
						$msg = 'Currency attribute "id" is not defined in YML file "' . $file_path . '"';
						$this->_error_log($msg);
						$this->app['DB']->useConnection();
						$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
						$this->app['DB']->closeConnection();
						//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
						$this->_breakStateFile();
						throw new Exception($msg);
					}
					if ( $currency->hasAttribute('rate') ) {
						$item['rate'] = $currency->getAttribute('rate');
					}
					$our_currency_code = isset($config['currency.map'] [$item['id']] ) ? $config['currency.map'] [$item['id']]: 0;
					if ($our_currency_code) {
						$obj = new stdClass();
						$obj->our_currency_code = $our_currency_code;
						$obj->rate = $item['rate'];
						$aCurrencies[$item['id']] = $obj;
					} else {
						$msg = 'Unknown currency Id ' . $item['id']  . ' in ' . $file_path;
						$this->_error_log($msg);
						$this->app['DB']->useConnection();
						$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
						$this->app['DB']->closeConnection();
						//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
						$this->_breakStateFile();
						throw new Exception($msg);
					}
				}
				if (count($aCurrencies)) {
					$data = array('currencies' => json_encode($aCurrencies));
					$where = ' id = ' . $id;
					$this->app['DB']->useConnection();
					$db->update('offers_xmlfeeds', $data, $where);
					$this->app['DB']->closeConnection();
				}
			} else {
				$msg = 'Error parse currency in file "' . $file_path . '"';
				$this->_error_log($msg);
				$this->app['DB']->useConnection();
				$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
				$this->app['DB']->closeConnection();
				//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
				$this->_breakStateFile();
				throw new Exception($msg);
			}
		} else {
			$msg = 'Error parse currency in file "' . $file_path . '"';
			$this->_error_log($msg);
			$this->app['DB']->useConnection();
			$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
			$this->app['DB']->closeConnection();
			//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
			$this->_breakStateFile();
			throw new Exception($msg);
		}
		$this->_currencies = $aCurrencies;
		$ex_categories_data = $this->_loadXmlFeedsCurrenciesAndCategories();
		$this->_calculateQuantityCategories($ex_categories_data, $quantity_categories, $quantity_new_categories);//TODO считаем количество новых и не новых категорий для даного xmlfeeds
		$categories_block = $doc->getElementsByTagName('categories');
		if ($categories_block->length > 0) {
			$categories = $categories_block->item(0)->getElementsByTagName('category');
			if ($categories->length > 0) {
				for ($i = 0; $i < $categories->length; $i++) {
					$category = $categories->item($i);
					$item = array();
					if ($category->hasAttribute('id')) {
						$item['id'] = $category->getAttribute('id');
					} else {
						$msg = 'Category attribute "id" is not defined in YML file "' . $file_path . '"';
						$this->_error_log($msg);
						$this->app['DB']->useConnection();
						$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
						$this->app['DB']->closeConnection();
						//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
						$this->_breakStateFile();
						throw new Exception($msg);
					}
					if ($category->hasAttribute('parentId')) {
						$item['parentId'] = $category->getAttribute('parentId');
					} else {
						$item['parentId'] = 0;
					}
					$item['name'] = $category->textContent;
					
					$do_insert = true;
					if ( isset($ex_categories_data[$item['id']]) ) {
						$do_insert = false;
						$ex_cat = $ex_categories_data[$item['id']];
						if ($ex_cat['src_name'] != $item['name']) {
							$this->app['DB']->useConnection();
							$db->update('xml_products_categories_data', array('src_name' => $item['name']), "offers_xmlfeeds_id = {$this->_xmlfeeds_id} AND src_cat_id = {$item['id']}");
							$this->app['DB']->closeConnection();
						} else {
							$this->_error_log("Категория с исходным идентификатором {$item['id']} уже существует, ей назначена наша категория {$ex_cat['our_cat_id']}, но {$ex_cat['src_name']} = {$item['name']}, {$ex_cat['src_parent_id']}={$item['parentId']}");
						}
					}
					if ($do_insert) {
						$quantity_categories++;
						$quantity_new_categories++;
						$data = array('offer_id' => $offer_id, 'offers_xmlfeeds_id' => $id, 'src_cat_id' => $item['id'], 'src_name' => $item['name'], 'src_parent_id' => $item['parentId'], 'our_cat_id' => 0, 'category_process_status' => 2);
						$this->app['DB']->useConnection();
						$data['id'] = $db->insert('xml_products_categories_data', $data);
						$this->app['DB']->closeConnection();
						$ex_categories_data[ $data['src_cat_id'] ] = $data;
					}
				}
				$this->_categories = $ex_categories_data;
				$this->app['DB']->useConnection();
				$db->update('offers_xmlfeeds', array('quantity_categories' => $quantity_categories, 'quantity_new_categories' => $quantity_new_categories), 'id = ' . $this->_xmlfeeds_id);
				$db->update('xml_products_categories_data', array('category_process_status' => 0), 'offers_xmlfeeds_id = ' . $this->_xmlfeeds_id);
				$this->app['DB']->closeConnection();
			} else {
				$msg = 'Error parse category in file "' . $file_path . '"';
				$this->_error_log($msg);
				$this->app['DB']->useConnection();
				$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
				$this->app['DB']->closeConnection();
				//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
				$this->_breakStateFile();
				throw new Exception($msg);
			}
		} else {
			$msg = 'Error parse categories in file "' . $file_path . '"';
			$this->_error_log($msg);
			$this->app['DB']->useConnection();
			$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
			$this->app['DB']->closeConnection();
			//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
			$this->_breakStateFile();
			throw new Exception($msg);
		}
	}
	/**
	 *@desc   Скачивает файл в директорию временых файлов
	 *@param  string $url адрес файла
	 *@param  int $id идентификатор записи в offers_xmlfeeds 
	 *@return bool|string путь к временному файлу, если удалось скачать или false
	**/
	private function _download($url, $id) {
		$tmp_file_name = $this->_yml_dir . '/' . $id . '_tmp.xml';
		$process = curl_init($url);
		curl_setopt($process, CURLOPT_HEADER, 0);
		$headers = array(
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language: ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3'
		);
		curl_setopt($process, CURLOPT_HTTPHEADER,$headers);
		curl_setopt($process, CURLOPT_TIMEOUT, 0);
		curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
		
		$writer = fopen($tmp_file_name, 'w');
		curl_setopt($process, CURLOPT_FILE, $writer);
		$return = curl_exec($process);
		curl_close($process);
		fclose($writer);
		return $tmp_file_name;
	}
	/**
	 *@desc   Скачивает файл в директорию временых файлов
	 *@param  string $url адрес файла
	 *@param  int $id идентификатор записи в offers_xmlfeeds 
	 *@return bool|string путь к временному файлу, если удалось скачать или false
	**/
	private function _error_log($msg) {
		$mongo = $this->app['Mongo'];
		$mongo->useCollection('main', 'yml_parser_log');
		$data = array(
			'offer_id' => $this->_offer_id,
			'xmlfeeds_id' => $this->_xmlfeeds_id,
			'text' => $msg,
			'is_error' => 1,
			'ttl' => $mongo->mongoDate()
		);
		$mongo->insert($data);
	}
	
	/**
	 *@desc   Скачивает файл в директорию временых файлов
	 *@param  DOMNode $offer DOM - объект оффера
	 *@param  array &$array массив, в который будут добавлены теги, имен которых  которых нет в $keys
	 *@param  array $keys массив имен тегов, которые будут игнорироваться
	**/
	private function _grabUnknownTags($offer, &$array, $keys) {
		$keys['picture'] = 0;
		$keys['param'] = 0;
		$node = $offer->firstChild;
		while (true) {
			if (!$node) {
				break;
			}
			$tagName = trim($node->tagName);
			if ($tagName) {
				if (!array_key_exists($tagName, $keys)) {
					$array[$tagName] = $this->_getTag($offer, $tagName);
				}
			}
			$parentNode = $node;
			$node = $node->nextSibling;
			if (!$node)  {
				$node = $parentNode->firstChild;
			}
		}
	}
	/**
	 *@desc   Скачивает файл в директорию временых файлов
	 *@param  DOMNode $node DOM - node param
	 *@param  array &$param массив, в который будут добавлены атрибуты
	**/
	private function _getAllTagAttributes($node, &$param) {
		if ($node->hasAttributes()) {
		  foreach ($node->attributes as $attr) { 
			$param[$attr->nodeName] = $attr->nodeValue;
		  }
		}
	}
	/**
	 *@desc   Считаем количество новых и не новых категорий для текущего xmlfeeds
	 *@param  array $ex_categories_data
	 *@param  int &$quantity_categories
	 *@param  int &$quantity_new_categories
	**/
	private function _calculateQuantityCategories($ex_categories_data, &$quantity_categories, &$quantity_new_categories) {
		$quantity_categories = 0;
		$quantity_new_categories = 0;
		foreach ($ex_categories_data as $item) {
			if ($item['offers_xmlfeeds_id'] == $this->_xmlfeeds_id) {
				$quantity_categories++;
				if ($item['our_cat_id'] != 0) {
					$quantity_new_categories++;
				}
			}
		}
	}
	/**
	 * @desc Если количество товаров с неопределенной в файле категорией более 1-го процента 
	*	поставить каталог в очередь на модерацию
	**/
	private function _checkQuantityUndefinedCategories() {
		$this->app['DB']->useConnection();
		$total = (int)$this->app['DB']->getValue('SELECT quantity_products FROM offers_xmlfeeds WHERE id = ' . $this->_xmlfeeds_id);
		if ($total) {
			if ($this->_quantityUndefinedCategories >= ($total / 100)) {
				$msg = 'Есть товар(ы) с категориями, не определенными в исходном дереве категорий в файле ' . $file_path ."\nНомера категорий: " . join(',', $this->_productUndefinedCategoriesIds);
				$this->_error_log($msg);
				$this->app['DB']->update('offers_xmlfeeds', array('status' => 1, 'parser_message' => $msg), ' id = ' . $this->_xmlfeeds_id);
			}
		}
		$this->app['DB']->closeConnection();
	}
	/**
	 * @desc Сбросить информацию в файле состояния. Записать все параметры в 0 
	*	 и очистить временную таблицу
	**/
	private function _breakStateFile() {
		file_put_contents($this->_last_state_file, "0\n0\n0\n0\n0\n0");
		//очистить временную таблицу.
		$this->app['DB']->useConnection();
		$this->app['DB']->runQuery('TRUNCATE TABLE tmp_products_data');
		$this->app['DB']->closeConnection();
	}
	/**
	 * @desc Считать информацию из файла состояния
	 * @param string &$file_path записывает путь к xml файлу  
	 * @param int &$file_id записывает идентификатор xml каталога  
	 * @param int &$offer_id записывает идентификатор оффера  
	 * @param int &$offset записывает смещение в байтах от начала файла или от начала таблицы products в зависмости от режима $mode
	 * @param int &$mode 0 - режим парсинга файла, 1 - режим установки флага  is_deleted_in_source
	 * @param int &$count_update - 0 - во время парсинга файла не было выполнено ни одного update products, 1 - было update products
	 * @param string &$error_msg информация об ошибке
	 * @return bool если удалось прочесть файл, false если не удалось
	*/
	private function _readStateFile(&$file_path, &$file_id, &$offer_id, &$offset, &$mode, &$count_update, &$error_msg) {
		if (!file_exists($this->_last_state_file)) {
			$error_msg = 'File ' . $this->_last_state_file . ' not found' . "\n";
			return false;
		}
		$a_last_state = explode("\n", file_get_contents($this->_last_state_file));
		if (count($a_last_state) == 6) {
			$xml_dir = $this->_yml_dir;
			$file_path   = $xml_dir . '/' . (int)$a_last_state[0] . '.xml';
			if ($file_id && !file_exists($file_path)) {
				$error_msg = 'File ' . $file_path . ' not found' . "\n";
				return false;
			}
			$file_id     = (int)$a_last_state[1];
			$offer_id     = (int)$a_last_state[2];
			$offset = (int)$a_last_state[3];
			$this->_mode = $mode = (int)$a_last_state[4];
			$count_update = (int)$a_last_state[5];
			if ($count_update) {
				$this->_update_flag = true;
			}
			return true;
		}
		$error_msg = 'Invalid quantity  lines in file ' . $this->_last_state_file . ' ' . "\n";
		return false;
	}
	/**
	 * @desc Записать состояние в файл состояния
	 * @param $file_name имя xml файла, -- по идее всегда будет совпадать с id, но лучше перестраховаться
	 * @param $file_id id его записи в БД,
	 * @param $offer_id его записи в БД,
	 * @param $offset смещение от его начала  или от начала таблицы products в зависмости от режима $mode
	 * @param int $mode 0 - режим парсинга файла, 1 - режим установки флага  is_deleted_in_source
	 * @param int $count_update - 0 - во время парсинга файла не было выполнено ни одного update products, 1 - было update products
	 	 
	 **/
	private function _writeStateFile($file_name, $file_id, $offer_id, $offset, $mode, $count_update) {
		if ($count_update == 1) {
			$this->_update_flag = true;
		}
		file_put_contents($this->_last_state_file, "{$file_name}\n{$file_id}\n{$offer_id}\n{$offset}\n{$mode}\n{$count_update}");
	}
	/**
	 * @desc Переустановить флаг is_deleted_in_source
	 * @param $xml_catalog_id
	 * @param $offset таблицы products
	 **/
	private function _resetIsDeleteInSourceFlag($xml_catalog_id, $offset) {
		include $this->_tmp_dir . '/cpoint.php';
		cpoint('Start', 'set');
		$limit = Yml_Parser::OFFERS_PER_BLOCK;
		$sql_query_tpl = 'SELECT src_product_id, id FROM products WHERE xml_catalog_id = ' . $xml_catalog_id . ' ORDER BY id OFFSET {OFFSET} LIMIT ' . $limit;
		while (true) {
			$sql_query = StrFuncs::app_str_replace('{OFFSET}', $offset, $sql_query_tpl);
			$this->app['DB']->useConnection();
			$rows = $this->app['DB']->runQuery($sql_query);
			$this->app['DB']->closeConnection();
			
			
			//debug info
			$cu = 0;
			
			//собрать номера
			$ids = array();
			$count = 0;
			foreach ($rows as $row) {
				$ids[] = $row['src_product_id'];
				$count++;
			}
			if ($count) {
				$sql_query = 'SELECT src_product_id FROM tmp_products_data WHERE src_product_id IN ('. join(',', $ids) .') AND xml_catalog_id = ? LIMIT 1';
				$this->app['DB']->useConnection();
				$tmp_rows = $this->app['DB']->runQuery($sql_query, array($xml_catalog_id));
				$this->app['DB']->closeConnection();
				cpoint('get records');
				$flags = array();
				foreach ($tmp_rows as $row) {
					$flags[ $row['src_product_id'] ] = 1;
				}
				foreach ($rows as $row) {
					if (!isset($flags[ $row['src_product_id'] ])) {
						$this->app['DB']->useConnection();
						$this->app['DB']->update('products', array('is_deleted_in_source' => 'TRUE'),  ' id = ' . $row['id']);
						$this->app['DB']->closeConnection();
						$cu++;
					}
				}
			}
			
			//старый код
			/*$count = 0;
			foreach ($rows as $row) {
				$sql_query = 'SELECT COUNT(src_product_id) FROM tmp_products_data WHERE src_product_id = ? AND xml_catalog_id = ? LIMIT 1';
				$this->app['DB']->useConnection();
				$is_exists = $this->app['DB']->getValue($sql_query, array($row['src_product_id'], $xml_catalog_id));
				$this->app['DB']->closeConnection();
				if (!$is_exists) {
					$this->app['DB']->useConnection();
					$this->app['DB']->update('products', array('is_deleted_in_source' => 'TRUE'),  ' id = ' . $row['id'] . ' AND xml_catalog_id = ' . $xml_catalog_id);
					$this->app['DB']->closeConnection();
				}
				$count++;
			}*/
			
			
			if (!$count) {
				break;
			}
			$offset += $limit;
			$this->_writeStateFile($xml_catalog_id, $xml_catalog_id, $this->_offer_id, $offset, 1, 1);
		}
		cpoint('1103 - cu = ' . $cu);
		$this->_endParse($xml_catalog_id);
	}
	/**
	 * @desc Пометить каталог как обработанный
	 * @param $xml_catalog_id
	*/
	private function _endParse($xml_catalog_id){
		$this->app['DB']->useConnection();
		$this->app['DB']->update('offers_xmlfeeds', array('parsing_status' => 2), 'id = ' . $xml_catalog_id);
		$this->app['DB']->closeConnection();
		//Если количество товаров с неопределенной в файле категорией более 1-го процента
		//поставить каталог в очередь на модерацию
		$this->_checkQuantityUndefinedCategories();
		//file_put_contents($this->_last_state_file, "0\n0\n0\n0");
		$this->_breakStateFile();
	}
}
