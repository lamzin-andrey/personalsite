-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Окт 10 2014 г., 13:35
-- Версия сервера: 5.6.16
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `fx`
--

-- --------------------------------------------------------

--
-- Структура таблицы `js_scripts`
--

CREATE TABLE IF NOT EXISTS `js_scripts` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `src_file_name` varchar(32) DEFAULT NULL COMMENT 'исходное имя файла',
  `display_file_name` varchar(128) DEFAULT NULL COMMENT 'отображаемое имя файла',
  `file_content` text COMMENT 'отображаемое имя файла',
  `user_id` int(11) DEFAULT NULL COMMENT 'id пользователя - владельца файла',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `date_update` datetime DEFAULT NULL COMMENT 'время обновления',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=97 ;

--
-- Дамп данных таблицы `js_scripts`
--

INSERT INTO `js_scripts` (`id`, `src_file_name`, `display_file_name`, `file_content`, `user_id`, `date_create`, `date_update`, `is_deleted`, `delta`) VALUES
(2, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 1, '2014-10-02 01:25:48', '2014-10-02 01:25:48', 0, NULL),
(3, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:16:45', '2014-10-02 13:16:45', 0, NULL),
(4, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:23:39', '2014-10-02 13:23:39', 0, NULL),
(5, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:28:30', '2014-10-02 13:28:30', 0, NULL),
(6, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:34:04', '2014-10-02 13:34:04', 0, NULL),
(7, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:48:21', '2014-10-02 13:48:21', 0, NULL),
(8, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:49:54', '2014-10-02 13:49:54', 0, NULL),
(9, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:51:11', '2014-10-02 13:51:11', 0, NULL),
(10, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:53:13', '2014-10-02 13:53:13', 0, NULL),
(11, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:54:19', '2014-10-02 13:54:19', 0, NULL),
(12, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:55:14', '2014-10-02 13:55:14', 0, NULL),
(13, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:56:16', '2014-10-02 13:56:16', 0, NULL),
(14, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:57:16', '2014-10-02 13:57:16', 0, NULL),
(15, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:57:46', '2014-10-02 13:57:46', 0, NULL),
(16, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 3, '2014-10-02 13:58:27', '2014-10-02 13:58:27', 0, NULL),
(17, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:03:14', '2014-10-02 15:03:14', 1, NULL),
(18, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:03:26', '2014-10-02 15:03:26', 1, NULL),
(19, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:04:33', '2014-10-02 15:04:33', 1, NULL),
(20, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:13:08', '2014-10-02 15:13:08', 1, NULL),
(21, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:15:40', '2014-10-02 15:15:40', 1, NULL),
(22, 'task1.js', 'Вычисление факториалов', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:15:52', '2014-10-02 16:29:00', 0, NULL),
(23, 'task1.js', 'ТОже какая-то хрень', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 15:16:29', '2014-10-02 15:16:29', 1, NULL),
(24, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 16:29:09', '2014-10-02 16:29:09', 1, NULL),
(25, 'task1.js', 'ТОжде кодер', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 27, '2014-10-02 16:52:10', '2014-10-02 16:52:10', 0, NULL),
(26, 'task1.js', 'Task1', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 16:58:18', '2014-10-02 17:05:42', 1, NULL),
(27, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 17:04:56', '2014-10-02 17:04:56', 1, NULL),
(28, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 17:25:12', '2014-10-02 17:25:12', 1, NULL),
(29, 'task1.js', 'Вычисление факториалоыв', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 28, '2014-10-02 17:35:56', '2014-10-03 15:56:05', 1, NULL),
(30, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 26, '2014-10-02 18:34:17', '2014-10-02 18:34:17', 1, NULL),
(31, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 28, '2014-10-02 18:34:58', '2014-10-02 18:34:58', 1, NULL),
(32, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 29, '2014-10-03 15:26:56', '2014-10-03 15:26:56', 1, NULL),
(33, 'task1.js', 'Fack', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 28, '2014-10-03 15:59:13', '2014-10-03 15:59:13', 1, NULL),
(34, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 29, '2014-10-03 16:00:11', '2014-10-03 16:00:11', 1, NULL),
(35, 'task1.js', '', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 29, '2014-10-03 16:01:25', '2014-10-03 16:01:25', 0, NULL),
(36, 'task1.js', 'Вычисление факториала', '//Программка вычисления факториала\n/**\n * @desc Это просто\n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 28, '2014-10-03 16:02:55', '2014-10-03 21:40:54', 0, NULL),
(37, 'start.js', '', '﻿function start() {\r\n	writeln(''Hello!'');\r\n}', 30, '2014-10-03 16:35:10', '2014-10-03 16:35:10', 1, NULL),
(38, 'start.js', '', '﻿function start() {\r\n	writeln(''Hello!'');\r\n}', 30, '2014-10-03 16:36:44', '2014-10-03 16:36:44', 1, NULL),
(39, 'task1.js', 'ss', '//Программка вычисления факториала\n/**\n * \n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	var r = 1;\n	for (var i = 1; i <= n; i++) {\n		r *= i;\n	}\n	writeln(n + "! = " + r);\n}\n', 32, '2014-10-05 22:25:47', '2014-10-05 22:25:47', 0, NULL),
(40, 'a', 'Assar', '', 37, '2014-10-07 22:19:31', '2014-10-07 22:19:31', 1, NULL),
(41, 'assa', 'Budl', '', 37, '2014-10-07 22:23:38', '2014-10-07 22:23:38', 1, NULL),
(42, 'assa', '', 'function assa() {\n	alert(105); \n}', 37, '2014-10-07 22:25:01', '2014-10-07 22:25:01', 1, NULL),
(43, 'Arra', 'dee', 'function Arra() {\n	alert(102);\n}', 37, '2014-10-07 22:28:49', '2014-10-07 22:28:49', 1, NULL),
(44, 'allo', 'Bellodonna', 'function allo() {\n	alert(''Lifa'');\n}', 37, '2014-10-07 22:54:29', '2014-10-07 22:54:29', 1, NULL),
(45, 'asel', 'Threese', 'function asel() {\n	alert(33333);\n}', 37, '2014-10-07 22:56:44', '2014-10-07 22:56:44', 1, NULL),
(46, 'allo', 'Bassel', 'function allo() {\n	alert(''Lifa'');\n}', 37, '2014-10-07 23:00:23', '2014-10-07 23:00:23', 1, NULL),
(47, 'allo', 'ss', 'function allo() {\n	alert(''Lifa'');\n}', 37, '2014-10-07 23:00:36', '2014-10-07 23:00:36', 1, NULL),
(48, 'allo', 'ttest', 'function allo() {\n	alert(''Lifa'');\n}', 37, '2014-10-07 23:02:40', '2014-10-07 23:02:40', 1, NULL),
(49, 'allo', 'ttest', 'function allo() {\n	alert(''Lifa'');\n}', 37, '2014-10-07 23:02:46', '2014-10-07 23:02:46', 1, NULL),
(50, 'alloc', 'llok', 'function alloc() {\n	alert(''Lifan'');\n}', 37, '2014-10-07 23:07:14', '2014-10-07 23:07:14', 1, NULL),
(51, 'alloc2', 'Bazzy', 'function alloc2() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:21:53', '2014-10-09 07:21:53', 1, NULL),
(52, 'alloc3', 'Three', 'function alloc3() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:27:20', '2014-10-09 07:27:20', 1, NULL),
(53, 'alloc4', 'Wis', 'function alloc4() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:28:53', '2014-10-09 07:28:53', 1, NULL),
(54, 'alloc5', 'sss', 'function alloc5() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:30:50', '2014-10-09 07:30:50', 1, NULL),
(55, 'alloc9', 'fff', 'function alloc9() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:33:26', '2014-10-09 07:33:26', 1, NULL),
(56, 'alloc10', '15', 'function alloc10() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:36:05', '2014-10-09 07:36:05', 1, NULL),
(57, 'alloc11', 'f', 'function alloc11() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:36:32', '2014-10-09 07:36:32', 1, NULL),
(58, 'alloc12', '778', 'function alloc12() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:38:38', '2014-10-09 07:38:38', 1, NULL),
(59, 'alloc13', 'f', 'function alloc13() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:44:37', '2014-10-09 07:44:37', 1, NULL),
(60, 'alloc14', 'yuy', 'function alloc14() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:44:52', '2014-10-09 07:44:52', 1, NULL),
(61, 'alloc15', 'hj', 'function alloc15() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:45:36', '2014-10-09 07:45:36', 1, NULL),
(62, 'alloc16', 'd', 'function alloc16() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:46:19', '2014-10-09 07:46:19', 1, NULL),
(63, 'alloc17', 'd', 'function alloc17() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:53:20', '2014-10-09 07:53:20', 1, NULL),
(64, 'alloc18', 'd', 'function alloc18() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:53:59', '2014-10-09 07:53:59', 1, NULL),
(65, 'alloc19', 'ddd', 'function alloc19() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:54:22', '2014-10-09 07:54:22', 1, NULL),
(66, 'alloc20', 'rt', 'function alloc20() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:55:00', '2014-10-09 07:55:00', 1, NULL),
(67, 'alloc21', 't', 'function alloc21() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:56:52', '2014-10-09 07:56:52', 1, NULL),
(68, 'alloc22', 'uuu', 'function alloc22() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 07:59:04', '2014-10-09 07:59:04', 1, NULL),
(69, 'alloc23', 'dd', 'function alloc23() {\n	writeln(''Start'');\n	var v = readln(''Get me anu'');\n    writeln(''you enter '' + v);\n	var r = 150;\n	r += 15;\n}', 37, '2014-10-09 08:00:16', '2014-10-09 08:00:16', 1, NULL),
(70, 'alloc24', 'Ured', 'function will() {\n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n}', 37, '2014-10-09 08:09:14', '2014-10-09 08:09:14', 1, NULL),
(71, 'will', 'Просто тстю', 'function will() {\n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n}', 37, '2014-10-09 09:46:53', '2014-10-09 09:46:53', 1, NULL),
(72, 'willBe', 'Гомер', 'function willBe() {\n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n}', 37, '2014-10-09 09:47:46', '2014-10-09 09:47:46', 1, NULL),
(73, 'willBe', 'willBe', 'function willBe() {\n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n} ', 37, '2014-10-09 10:14:25', '2014-10-09 10:14:25', 1, NULL),
(74, 'willBe2', 'Wee', 'function willBe2() {\n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n    writeln(''you enter d '' + v);\n//dsadasdd\n} ', 37, '2014-10-09 10:17:29', '2014-10-09 10:17:29', 1, NULL),
(75, 'Buuk', 'dd', 'function Abby() { \n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n    writeln(''you enter d '' + v);\n	//hello\n} ', 37, '2014-10-09 10:19:00', '2014-10-09 10:19:00', 1, NULL),
(76, 'Abby', 'Buggy', 'function Aggu() { \n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n    writeln(''you enter d '' + v);\n	//hello \n}', 37, '2014-10-09 10:28:14', '2014-10-09 10:28:14', 0, NULL),
(77, 'Aggu', 'Что-то с чем то', 'function Aggu() { \n	writeln(''Start'');\n	var v = readln(''Get me any'');\n    writeln(''you enter '' + v);\n    writeln(''you enter d '' + v);\n	//hello \n}', 37, '2014-10-09 10:33:10', '2014-10-09 10:33:10', 0, NULL),
(78, 'Abby', 'Holly', 'function Abby2(){\n	alert('''');\n	alert('''');\n	alert('''');\n}', 28, '2014-10-09 11:02:16', '2014-10-09 11:02:16', 1, NULL),
(79, 'MyFirst', 'Belle', 'function anno() {\n	//alert\n}', 38, '2014-10-09 11:03:36', '2014-10-09 11:03:36', 0, NULL),
(80, 'anno', 'Baas', 'function anno() {\n	//alert\n}', 38, '2014-10-09 11:04:02', '2014-10-09 11:04:02', 0, NULL),
(81, 'Agga', 'Zukr', 'function Agga() {\n	alert(1005200);\n	alert(1005200);\n}', 39, '2014-10-09 11:05:21', '2014-10-09 11:05:21', 0, NULL),
(82, 'Agga', 'agga', 'function Agga() {\n	alertHello();\n	write();\n}', 40, '2014-10-09 11:06:09', '2014-10-09 11:06:09', 0, NULL),
(83, 'Aggad', 'dds', 'function Aggad() {\n	var n = readln(''Hello, get me 10'');\n	if (n == 10) {\n		writeln(''Thank!'');\n	} else {\n		writeln(''Я просил 10, а вот на тебе...'');\n	}\n	writeln(''n = '' + n);\n	writeln(''n = '' + n);\n	writeln(''n = '' + n);\n	writeln(''n = '' + n);\n//ьуьуьу\n}', 40, '2014-10-09 11:07:00', '2014-10-09 11:07:00', 0, NULL),
(84, 'Abby2', 'На самом деле это тупо алерт', '//а так можно?\nfunction Abby2(){\n	alert('''');\n}\n\n\n\n', 28, '2014-10-09 11:17:14', '2014-10-09 11:17:14', 1, NULL),
(85, 'HelloWorld', 'Фееф', 'function HelloWorld() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 14:56:33', '2014-10-09 14:56:33', 1, NULL),
(86, 'HelloWorld3', 'Какой-то скрипт', 'function HelloWorld3() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 15:58:20', '2014-10-09 15:58:20', 0, NULL),
(87, 'HelloWorld8', 'dds', 'function HelloWorld8() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 16:09:21', '2014-10-09 16:09:21', 1, NULL),
(88, 'HelloWorld8', 'hg', 'function HelloWorld8() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 16:10:12', '2014-10-09 16:10:12', 1, NULL),
(89, 'HelloWorld8', 'hhg', 'function HelloWorld8() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 16:10:24', '2014-10-09 16:10:24', 1, NULL),
(90, 'HelloWorld8', 'hgfh', 'function HelloWorld8() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 16:10:39', '2014-10-09 16:10:39', 1, NULL),
(91, 'HelloWorld8', 'ffd', 'function HelloWorld8() {\n	writeln(''Heool QW'');\n}', 42, '2014-10-09 16:11:04', '2014-10-09 16:11:04', 1, NULL),
(92, 'my_first', 'boost', 'function my_first() {\n	alert(''Это точно буст?'');\n	var v = readln(''ВВедите количество лет'');\n}', 43, '2014-10-09 18:19:00', '2014-10-09 18:19:00', 0, NULL),
(93, 'aurum', 'boosterd', 'function aurum() {\n	writeln(''Y=-io'');\n	var v = readln(''get me 5'');\n	if (v == 5) {\n		writeln(''Маладэц!'');\n	} else {\n		writeln(''Скатына!'');\n	}\n}', 30, '2014-10-09 19:51:18', '2014-10-09 19:51:18', 0, NULL),
(94, 'my_second', 'Глупости', 'function my_second() {\n	//здесь все остальное\n	alert(''А это мы выведем в всплывающем окне'');//стандартная функция браузерого JavaScript\n	writeln(''А это мы выведем в консоли вывода приложения'');//А эта функция написана мной и \n								//определена только на этом сайте\n}', 43, '2014-10-09 20:40:53', '2014-10-09 20:40:53', 0, NULL),
(95, 'task1', 'Рекурсивный факториал', '//Программка вычисления факториала\n/**\n * @desc Это просто\n * */\nfunction task1() {\n	var n = parseInt(readln(''Введите n''));	\n	if (n === 0 || n === ''0'') {\n		writeln(n + "! = 1");\n		return;\n	}\n	if (isNaN(n) || !n) {\n		writeln(''n должно быть числом'');\n		return;\n	}\n	function fact(n) {\n		if (n <= 1) {\n			return 1;\n		}\n		return n * fact(n - 1);\n	}\n	writeln(''n! = '' + fact(n));\n}\n', 28, '2014-10-09 20:46:19', '2014-10-09 20:46:19', 0, NULL),
(96, 'Hello', 'Это просто баловство', 'function Hello() {\n	var a = 5;\n	var b = 5;\n	var c =  a + b;\n	writeln("c = " + c);\n}', 28, '2014-10-09 21:52:34', '2014-10-09 21:52:34', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `pwd` varchar(32) DEFAULT NULL COMMENT 'пароль',
  `email` varchar(64) DEFAULT NULL COMMENT 'email',
  `guest_id` varchar(32) DEFAULT NULL COMMENT 'md5( ip datetime) анонимного пользователя загрузившего файл',
  `last_access_time` datetime DEFAULT NULL COMMENT 'время последнего обращения к файлу',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `pwd`, `email`, `guest_id`, `last_access_time`, `is_deleted`, `date_create`, `delta`) VALUES
(1, NULL, NULL, 'a1cbdd73363659645266747633bfeb2d', NULL, 0, NULL, NULL),
(2, NULL, NULL, '00139964d9bebe607148e0f9f2c77e28', NULL, 0, NULL, NULL),
(3, NULL, NULL, '9cdac9186dc3de9912d5a22763b75681', NULL, 0, NULL, NULL),
(4, NULL, NULL, '576d8f81eb00b70b06952f2fc544a38a', NULL, 0, NULL, NULL),
(5, NULL, NULL, 'd3fbf968929d72f3f98b8efd4536f8b0', NULL, 0, NULL, NULL),
(6, NULL, NULL, '05ae81374a530b16e612583ab8ed742c', NULL, 0, NULL, NULL),
(7, NULL, NULL, 'ec1c172ea822aa7fe4350a101e931c7c', NULL, 0, NULL, NULL),
(8, NULL, NULL, 'f16582d251a4a6ef9eab444f4bdaeee1', NULL, 0, NULL, NULL),
(9, NULL, NULL, '47dd230dd9178938ef141c6ea5fa103f', NULL, 0, NULL, NULL),
(10, NULL, NULL, '91ea501c7de49fe3108ca4f3a839bd65', NULL, 0, NULL, NULL),
(11, NULL, NULL, 'a8a8e24cda16f9010ecb9b4882f5ff77', NULL, 0, NULL, NULL),
(12, NULL, NULL, '79b27ffe5ecf7ced5fba84c633c98eae', NULL, 0, NULL, NULL),
(13, NULL, NULL, '94104ba33da7756f61ef758b12f2325e', NULL, 0, NULL, NULL),
(14, NULL, NULL, '4e875256b2429afb420badd0fe6f36f8', NULL, 0, NULL, NULL),
(15, NULL, NULL, '2aa3d80cd53aa136698425ee7882794e', NULL, 0, NULL, NULL),
(16, NULL, NULL, '2a625b8737299e0eba53f8b76cb9623f', NULL, 0, NULL, NULL),
(17, NULL, NULL, 'd5978b3e26dec7eb1036c05ced94f103', NULL, 0, NULL, NULL),
(18, NULL, NULL, '43143bdfac86a4e75bf18e842b89d92a', NULL, 0, NULL, NULL),
(19, NULL, NULL, '6a6eb9afb9b4983cc94cf3d9acd1a399', NULL, 0, NULL, NULL),
(20, NULL, NULL, '21c6be9c5342e9fefe260bb80c444f34', NULL, 0, NULL, NULL),
(21, NULL, NULL, '42e1fcfefd8b92241386fb28b46753fa', NULL, 0, NULL, NULL),
(22, NULL, NULL, '54deed6e3c2ff4a143a2a6fa384380aa', NULL, 0, NULL, NULL),
(23, NULL, NULL, '8c685845caa765898b97e44b18f9df7e', NULL, 0, NULL, NULL),
(24, NULL, NULL, 'bbe04d827d738965194b96ef4985e360', NULL, 0, NULL, NULL),
(25, NULL, NULL, 'e88f2667495956b21c98387600247679', NULL, 0, NULL, NULL),
(26, NULL, NULL, 'f9da34c8cd09202beb6d2f4975f38706', NULL, 0, NULL, NULL),
(27, NULL, NULL, '867c4fc321cc14f7230f3fc8c9daf3ba', NULL, 0, NULL, NULL),
(28, NULL, NULL, '52b8070c151c75f07f77c74dd1bdaf46', NULL, 0, NULL, NULL),
(29, NULL, NULL, 'ba2935847511ff7f0c15495e2b5da9fd', NULL, 0, NULL, NULL),
(30, NULL, NULL, '866ed6cf93bea120f1a1968e5e95d031', NULL, 0, NULL, NULL),
(31, NULL, NULL, '3950b9bb4908e40d3e630a8d0b031264', NULL, 0, NULL, NULL),
(32, NULL, NULL, 'd3de609eb75b73fc767760705f1585b0', NULL, 0, NULL, NULL),
(33, NULL, NULL, '5e3452ffc5d99bb6e4fd7fae6c778112', NULL, 0, NULL, NULL),
(34, NULL, NULL, '844c22f77d4361e8e5bb794bb42ac16f', NULL, 0, NULL, NULL),
(35, NULL, NULL, '3aedb4ca92bd676e0564140c6d098cf4', NULL, 0, NULL, NULL),
(36, NULL, NULL, 'f70a45fe166e760f3941bbb86fade93e', NULL, 0, NULL, NULL),
(37, NULL, NULL, 'e7f147ea034a629489247d89413ad670', NULL, 0, NULL, NULL),
(38, NULL, NULL, 'f47686b1e903b4c49c475e3450ab2510', NULL, 0, NULL, NULL),
(39, NULL, NULL, '2f993fe5c61c98caa09a69db2240e12d', NULL, 0, NULL, NULL),
(40, NULL, NULL, '68b2766d44697f960516b4db66622d21', NULL, 0, NULL, NULL),
(41, NULL, NULL, '9e1c665b97c82c1e8b145968923ccee9', NULL, 0, NULL, NULL),
(42, NULL, NULL, '01f6e0a58afe6dabf04abe3516b9e38d', NULL, 0, NULL, NULL),
(43, NULL, NULL, '2e5eb87ef54d79fa46b921ac2755bd74', NULL, 0, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
