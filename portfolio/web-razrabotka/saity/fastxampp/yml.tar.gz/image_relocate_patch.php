<?php
require ('init.php');

$app['DB']->app = $app;

function relocateImages($db) {
	//product
    $dest_root = "/home/cpa/public_html/upload/products/images/36";
    
    $list = scandir($dest_root);
    $count = count($list);
    for ($i = 0; $i < $count; $i++) {
		$folder = $list[$i];
		if ($folder != '.' && $folder != '..') {
			$iFolder = (int)$folder;
			$folder = "{$dest_root}/{$folder}";
			if (is_dir($folder) && $iFolder) {
				$db->useConnection();
				$v = $db->getValue("SELECT COUNT(id) FROM products WHERE id = {$iFolder}");
				$db->closeConnection();
				if (!$v) {
					system("rm -r {$folder}");
				}
			}
		}
	}
}

relocateImages($app['DB']);

